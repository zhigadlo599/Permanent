1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"ViewportBoundary"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
0:{"buildId":"6NR4JTy_lHRYMevx-xw19","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","title","0",{"children":"Anna Permanent | Студія перманентного макіяжу"}],["$","meta","1",{"name":"description","content":"Професійний перманентний макіяж у Житомирі. Брови, губи, стрілки. Запис через Instagram @anna.permanent_zt"}],["$","meta","2",{"name":"generator","content":"v0.app"}]]
