__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_b0a279d5._.js",
  "static/chunks/node_modules_next_app_72f3d36f.js",
  "static/chunks/[next]_entry_page-loader_ts_742e4b53._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_7f09fef0._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js",
  "static/chunks/pages__app_2da965e7._.js",
  "static/chunks/turbopack-pages__app_5d693f93._.js"
])
